demoApp.factory("myFactory", function(stringValue) {
    return stringValue;
});