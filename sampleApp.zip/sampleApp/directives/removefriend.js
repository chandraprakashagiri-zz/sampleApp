demoApp.directive('removeFriend', function() {
    return {
        restrict: "E",
        templateUrl: "views/removeFriend.html",


    }
})